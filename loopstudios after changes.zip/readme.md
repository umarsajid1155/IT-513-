# Loopstudios Website

Loopstudios landing page from my Tailwind course and from [Frontend Mentor Challenge](https://www.frontendmentor.io/challenges/loopstudios-landing-page-N88J5Onjw)

## Usage

Install dependencies

```
npm Install
```

Run Tailwind CLI

```
npm run watch
```

![Alt text](images/loopstudios.png)
